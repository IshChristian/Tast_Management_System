<?php
 include "config.php";
 session_start();
?>

<html lang="en">
<head>
  <script>location.href="users/index.php"</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="admin/assets/css/demo.css" rel="stylesheet" />

    <link href="admin/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="admin/assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="admin/assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="admin/assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row">
            <h1>Tast Management System</h1>
        </div>
        <br>
        <br>
        <br>
        <br>

    <div class="content-wrapper">
             <div class="row justify-content-center shadow-lg p-9 mb-9 bg-dark">
        <div class="col-md-8 d-flex align-items-stretch grid-margin">
              <div class="flex-grow">
        <div class="col-12 stretch-card ">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Login Form</h4>
                      <p class="card-description" name="error">
                      <!-- <div class="col-md-3">
                                    <button class="btn btn-default btn-block" onclick="demo.showNotification('top','center')">Top Center</button>
                                </div> -->
                      </p>
                      <form action="index.php" method="post" class="forms-sample">
                        <div class="form-group row">
                          <label for="exampleInputEmail2" class="col-sm-3 col-form-label">Name</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="username" id="exampleInputEmail2" placeholder="Enter email">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Password</label>
                          <div class="col-sm-9">
                            <input type="password" name="password" class="form-control" id="exampleInputPassword2" placeholder="Password">
                          </div>
                        </div>
                        <button type="submit" name="btn" class="btn btn-success">Submit</button>
                        
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
</body>
</html>

<?php
if(isset($_POST['btn'])){
 @$use=$_POST['username'];
 @$pass=$_POST['password'];
 $sel=mysqli_query($conn, "SELECT * FROM users WHERE username='$use' AND password='$pass'");
 while($row=mysqli_fetch_array($sel)){
  @$username=$row['username'];
  @$password=$row['password'];
  $_SESSION['uid']=$row['id'];
 }
 $sel=mysqli_query($conn, "SELECT * FROM admin WHERE name='$use' AND password='$pass'");
 while($row=mysqli_fetch_array($sel)){
  @$name=$row['name'];
  @$word=$row['password'];
 }

 if($_POST['username'] == @$username && $_POST['password'] == @$password){
  header('location:users/index.php');
 }else if($_POST['username'] == @$name && $_POST['password'] == @$word){
  header('location:admin/index.php');
 }else{
  echo "<script>console.log('not connect')</script>";
 }
 if(!$conn){
  echo "<script>console.log('connect')</script>";
}else{
  echo "<script>console.log('not connect')</script>";
}
} 

?>