<?php
 include "config.php";
 session_start();
 $uidd=$_SESSION['uid'];
 
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Paper Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<?php
    include "pages/header.php";
    ?>

    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Table List</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-panel"></i>
								<p>Stats</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
						<li>
                            <a href="#">
								<i class="ti-settings"></i>
								<p>Settings</p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <div class="content">
            
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-md-12">
                    <div class="col-lg-8 col-md-7">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">View Tast</h4>
                            </div>
                            <div class="content">
                                
                        </div>
                    </div>


                </div>
            </div>
        </div>
                        <div class="card">
                           
                            <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Recieved Tast</h4>
                                <p class="category">Lorem ipsum dolor, sit amet consectetu</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>
                                        <th>ID</th>
                                    	<th>Name</th>
                                    	<th>Started</th>
                                    	<th>Ended</th>
                                    	<th>About</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // $sel=mysqli_query($conn, "SELECT * FROM tast WHERE id='$uidd'");
                                        // while($row=mysqli_fetch_array($sel)){
                                        //     $idd=$row['id'];
                                        // }
                                        $sel=mysqli_query($conn, "SELECT * FROM tast WHERE user='$uidd'");
                                        while($row=mysqli_fetch_array($sel)){
                                            ?>
                                             <tr>
                                        	<td><?php echo $row['id'] ?></td>
                                        	<td><?php echo $row['category'] ?></td>
                                        	<td><?php echo $row['started'] ?></td>
                                            <td><?php echo $row['end'] ?></td>
                                        	<td><button type="button" class="btn btn-default waves-effect m-r-20" data-toggle="modal" data-target="#largeModal">TAST - VIEW ABOUT</button></td>
                                        	<form action="table.php" method="post"><td>
                                                <select name="act" class="form-control">
                                                    <option value="complete">complete</option>
                                                    <option value="pending">Pending</option>
                                                </select>
                                            </td>
                                            <td><button type="submit" name="goo" class="btn btn-primary">Submit Tast</button></td>
                                            <td></form>
                                            <div class="row">
                                                <div class="modal fade" id="largeModal" tabindex="-1" role="dialog">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title" id="largeModalLabel">Modal title</h4>
                                                    </div>
                                                    <div class="modal-body">
                                                    <div class="card card-user">
                                                        <div class="text">
                                                        About Tast
                                                        </div>
                                                        <div class="content">
                                                            <p><?php echo $row['about'] ?></p>
                                                        </div>
                                                    </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-link waves-effect">SAVE CHANGES</button>
                                                        <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
                                                    </div>
                                                </div>
                                            </div>      
                                            </td>
                                        </tr>
                                            <?php
                                        }
                                        ?>
                                       

                                    </tbody>
                                </table>

                            </div>
                            <div class="card">
                            <div class="header">
                                <h4 class="title">completed Tast</h4>
                                <p class="category">Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>
                                        <th>ID</th>
                                    	<th>Name</th>
                                    	<th>completed-date</th>
                                    	<th>Action</th>
                                
                                    </thead>
                                    <tbody>
                                        <?php 
                                    $sel=mysqli_query($conn, "SELECT tast.id,tast.act,tast.category,tast.end FROM tast WHERE user='$uidd' and act!='pending'");
                                        while($row=mysqli_fetch_array($sel)){
                                            ?>
                                             <tr>
                                        	<td><?php echo $row['id'] ?></td>
                                        	<td><?php echo $row['category'] ?></td>
                                        	<td><?php echo $row['end'] ?></td>
                                            <td><?php echo $row['act'] ?></td>
                                        </tr>
                                            <?php
                                        }
                                        ?>
                                       

                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                    <div class="modal fade" id="largeModal" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="largeModalLabel">Modal title</h4>
                        </div>
                        <div class="modal-body">
                        <div class="card card-user">
                            <div class="text">
                               About Tast
                            </div>
                            <div class="content">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus, quod commodi? Esse velit eius necessitatibus aliquid libero rerum sunt explicabo aspernatur odio. Provident maxime cumque placeat. Totam nostrum amet alias, consequuntur maiores unde sapiente molestiae ab commodi repellat dolorum iure sequi? Tenetur eligendi, corporis blanditiis voluptatibus tempora consectetur illum odio voluptatum porro incidunt ea natus culpa, quisquam in. Modi nobis excepturi molestiae necessitatibus, veritatis tenetur ab rem perferendis eius. Nam aliquid blanditiis, placeat nemo in voluptatem incidunt molestias esse accusantium, voluptas deleniti quaerat eos eveniet nesciunt. Pariatur natus ea voluptatibus aspernatur inventore sequi exercitationem molestiae rem, voluptatem, quam adipisci facilis provident, tempore est! Rem, culpa voluptate magnam exercitationem laboriosam optio nam fuga aliquam voluptatum sint eveniet adipisci, quia incidunt autem quidem inventore fugiat repellat. Ea, molestias expedita saepe deleniti eligendi dicta amet magnam quod, culpa, neque laboriosam ex! Aliquid cupiditate eligendi odio odit ratione nostrum voluptates. Aliquam, vitae ipsa quidem voluptas impedit labore ducimus voluptatem sint iusto, deserunt alias cum quam at maiores ad nulla fugit quia veritatis odio assumenda? Atque reprehenderit, ipsum dolore consectetur tempora sequi enim officiis ut fugiat tenetur deserunt provident amet nesciunt molestiae dolor aliquam cupiditate porro explicabo! Corrupti earum, aut quasi quaerat tempora inventore natus.</p>
                            </div>
                        </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-link waves-effect">SAVE CHANGES</button>
                            <button type="button" class="btn btn-link waves-effect" data-dismiss="modal">CLOSE</button>
                        </div>
                    </div>
                </div>
            </div>
            </div>
                        </div>
                    </div>


                   


                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="http://www.creative-tim.com">
                                Creative Tim
                            </a>
                        </li>
                        <li>
                            <a href="http://blog.creative-tim.com">
                               Blog
                            </a>
                        </li>
                        <li>
                            <a href="http://www.creative-tim.com/license">
                                Licenses
                            </a>
                        </li>
                    </ul>
                </nav>
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://www.creative-tim.com">Creative Tim</a>
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
<?php
if(isset($_POST['goo'])){
    $acti=$_POST['act'];
    $sql=mysqli_query($conn, "UPDATE `tast` SET act='$acti'");
}

?>
