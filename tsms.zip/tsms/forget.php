<?php
 include "config.php";
 session_start();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="admin/assets/css/demo.css" rel="stylesheet" />

    <link href="admin/assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="admin/assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="admin/assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="admin/assets/css/demo.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row">
            <h1>Tast Management System</h1>
        </div>
        <br>
        <br>
        <br>
        <br>

    <div class="content-wrapper">
             <div class="row justify-content-center shadow-lg p-9 mb-9 bg-dark">
        <div class="col-md-8 d-flex align-items-stretch grid-margin">
              <div class="flex-grow">
        <div class="col-12 stretch-card ">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Login Form</h4>
                      <p class="card-description" name="error">
                      <!-- <div class="col-md-3">
                                    <button class="btn btn-default btn-block" onclick="demo.showNotification('top','center')">Top Center</button>
                                </div> -->
                      </p>
                      <form action="forget.php" method="post" class="forms-sample">
                        <div class="form-group row">
                          <label for="exampleInputEmail2" class="col-sm-3 col-form-label">Name</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="username" placeholder="Enter username">
                          </div>
                        </div>
                        <div class="form-group row">
                          <label for="exampleInputEmail2" class="col-sm-3 col-form-label">role</label>
                          <div class="col-sm-9">
                            <input type="text" class="form-control" name="role" placeholder="Enter role">
                          </div>
                        </div>
                        
                        <button type="submit" name="btn" class="btn btn-success">Submit</button>
                        <br>
                        <br>
                        <br>
                        <?php
                        if(isset($_POST['btn'])){
                            @$use=$_POST['username'];
                            @$rl=$_POST['role'];
                        
                            $sel=mysqli_query($conn, "SELECT * FROM `users` WHERE username='$use' AND role='$rl'");
                            while($row=mysqli_fetch_array($sel)){
                            @$name=$row['username'];
                            @$id=$row['id'];
                            @$word=$row['role'];
                            }
                        
                            if($use == @$name && $rl == @$word){
                            ?>
                            <form action="forget.php" method="post" class="forms-sample">
                                                <div class="form-group row">
                                                <label for="exampleInputEmail2" class="col-sm-3 col-form-label">New Password</label>
                                                <div class="col-sm-9">
                                                    <input type="text" class="form-control" name="newp" placeholder="Enter New password">
                                                </div>
                                                </div>
                                                <button type="submit" name="go" class="btn btn-success">Update</button>
                                                
                                            </form>
                            <?php
                            }else{
                            echo "no";
                            }
                            }

                        ?>
                        
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
</body>
</html>
<?php
if(isset($_POST['go'])){
    $sel=mysqli_query($conn, "SELECT id FROM users WHERE username='$use'");
    while($row=mysqli_fetch_array($sel)){               
    @$id=$row['id'];
     }
 @$new=$_POST['newp'];
 $up=mysqli_query($conn, "UPDATE users SET password='$new' WHERE id='$id'");
}
 ?>