<?php
 include "config.php";
?>


<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Paper Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
	<?php
    include "pages/header.php";
    ?>

    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Table List</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-panel"></i>
								<p>Stats</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
						<li>
                            <a href="#">
								<i class="ti-settings"></i>
								<p>Settings</p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <div class="content">
            
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-md-12">
                    <div class="col-lg-8 col-md-7">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Add Tast</h4>
                            </div>
                            <div class="content">
                                <form action="table.php" method="post">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Tast</label>
                                                <select name="tast" class="form-control border-input">
                                                <option value="Select"></option>
                                                <?php    
                                            $sel=mysqli_query($conn, 'SELECT * FROM asigned');
                                            while($log=mysqli_fetch_array($sel)){
                                                ?>
                                        <tr>
                                        
                                        <option value="<?php echo $log['name'] ?>"><?php echo $log['name'] ?></option>
                                        </tr>
                                        <?php
                                            }
                                            ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Users</label>
                                                <select name="name" class="form-control border-input">
                                                <option value="Select"></option>
                                                <?php    
                                            $sel=mysqli_query($conn, 'SELECT * FROM users');
                                            while($log=mysqli_fetch_array($sel)){
                                                ?>
                                        
                                        <option value="<?php echo $log['id'] ?>"><?php echo $log['username'] ?></option>
                                        
                                        <?php
                                            }
                                            ?>
                                            </div>
                                        </div>
                                    </div>
                                     <br>
                                    <div class="row">
                                    <!-- <div class="col-md-4"> -->
                                        <!-- <div class="col-md-4">
                                            
                                        </div> -->
                                        <div class="col-md-4">
                                        <div class="form-group">
                                                <label>Started</label>
                                                <input type="date" class="form-control border-input" name="start" placeholder="Country" >
                                            </div>
                                            <div class="form-group">
                                                <label>End</label>
                                                <input type="date" class="form-control border-input" name="end" placeholder="Country" >
                                            </div>
                                        </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>About Me</label>
                                                <textarea rows="7" class="form-control border-input" name="about" placeholder="Here can be your description"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                       <button type="submit" name="btn" class="btn btn-info">ADD</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Tast Table</h4>
                                <p class="category">Here is a subtitle for this table</p>
                            </div>
                            <div class="content table-responsive table-full-width">
                                <table class="table table-striped">
                                    <thead>
                                        <th>ID</th>
                                    	<th>Tast</th>
                                        <th>User</th>
                                    	<th>Started</th>
                                    	<th>End-tast</th>
                                    	<th>About</th>
                                    </thead> 
                                    <tbody>
                                    <?php
                                            $sel=mysqli_query($conn, 'SELECT * FROM tast');
                                            while($log=mysqli_fetch_array($sel)){
                                                ?>
                                        <tr>
                                        	<td><?php echo $log['id'] ?></td>
                                        	<td><?php echo $log['category'] ?></td>
                                            <td><?php echo $log['user'] ?></td>
                                        	<td><?php echo $log['started'] ?></td>
                                        	<td><?php echo $log['end'] ?></td>
                                        	<td><?php echo $log['act'] ?></td>
                                        </tr>
                                        <?php
                                            }
                                        ?>
                                        
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>


                   


                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="http://www.creative-tim.com">
                                Creative Tim
                            </a>
                        </li>
                        <li>
                            <a href="http://blog.creative-tim.com">
                               Blog
                            </a>
                        </li>
                        <li>
                            <a href="http://www.creative-tim.com/license">
                                Licenses
                            </a>
                        </li>
                    </ul>
                </nav>
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://www.creative-tim.com">Creative Tim</a>
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
<?php
if(isset($_POST['btn'])){
    $nam=$_POST['name'];
    $ts=$_POST['tast'];
    $str=$_POST['start'];
    $nd=$_POST['end'];
    $abt=$_POST['about'];
    $ok=mysqli_query($conn, "INSERT INTO tast VALUES ('','$ts','$nam','$str','$nd','Pending','$abt')");
}
if($ok && $sel){
    header('location:table.php');
}
?>
