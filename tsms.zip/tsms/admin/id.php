<?php
$idd=$_GET['id'];
$_SESSION['id']=$idd;
if($idd){
    header('location:chat.php');
}
?>