<?php
$conn=mysqli_connect('localhost','root','','tast_db');
if(!$conn){
    echo "<script>console.log('connect')</script>";
}else{
    echo "<script>console.log('not connect')</script>";
}
?>