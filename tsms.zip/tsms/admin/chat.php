<?php
 include "config.php";
 session_start();
 @$uidd=$_SESSION['uid'];
 
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Paper Dashboard by Creative Tim</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <link href="assets/css/jquery.mCustomScrollbar.min.css" rel="stylesheet"/>
    <link href="assets/css/fontawesome-all.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>

    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="chat.css">
    <script src="chat.js"></script> 
    <script src="fontawesome-all.js"></script>
    <script src="assets/js/jquery.min.js"></script>

    <script src="assets/js/jquery.mCustomScrollbar.min.js"></script>

    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <style>
        div.scroll {
  background-color: transparent;
  width: 750px;
  height: 350px;
  overflow-x: hidden;
  overflow-y: auto;
  text-align: center;
  padding: 20px;
  
  
}
       
        </style>


</head>
<body >

<div class="wrapper">
	
    <?php
    include "pages/header.php";

    ?>

    <div class="main-panel">
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Baddest</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-panel"></i>
								<p>Stats</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
						<li>
                            <a href="#">
								<i class="ti-settings"></i>
								<p>Settings</p>
                            </a>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>


        <div class="content" >
            
                <div class="row">
                    <div class="">
                        <div class="card">
                            <div class="col-md-2"></div>
                           
	
		<div class="container-fluid h-100">
			<div class="row justify-content-center h-100">

				<div class="col-md-8 col-xl-1 chat">
					<div class="card" data-spy="scroll" data-target=".card-body" data-offset="10" >
						<div class="card-header msg_head">
							<div class="d-flex bd-highlight">
								<!-- <div class="img_cont">
									<img src="" class="rounded-circle user_img">
									<span class="online_icon"></span>
								</div> -->
								<div class="user_info">
									<span>Chat with User</span>
									<p>1767 Messages</p>
								</div>
								<div class="video_cam">
									<span><i class="fas fa-video"></i></span>
									<span><i class="fas fa-phone"></i></span>
								</div>
							</div>
							<span id="action_menu_btn"><i class="fas fa-ellipsis-v"></i></span>
							<div class="action_menu">
								<ul>
									<li><i class="fas fa-user-circle"></i> View profile</li>
									<li><i class="fas fa-users"></i> Add to close friends</li>
									<li><i class="fas fa-plus"></i> Add to group</li>
									<li><i class="fas fa-ban"></i> Block</li>
								</ul>
							</div>
						</div>
						<div class="card-body msg_card_body scroll">
                        <div class='d-flex justify-content-end mb-4'>
								<div class='msg_cotainer_send'>
                            <?php
                             $sel=mysqli_query($conn, "SELECT * FROM `admin`");
                             while($log=mysqli_fetch_array($sel)){
                                $id=$log['id'];
                             }
                             
                            $sel=mysqli_query($conn, "SELECT * FROM msg WHERE sid='$uidd' AND rid='$id' OR rid='$uidd' AND sid='$id'");
                            while($row=mysqli_fetch_array($sel)){
                                $msgg=$row['msg'];
                            
                                $is = ($row['sid'] == $uidd) ? "
                                float:left;
                                width: 70%;
                                border-radius: 25px;
                                background-color: #82ccdd;
                                padding: 10px;
                                position: relative;
                                word-break: 1px;
                                word-wrap: break-word;
                                    
                                " : "
                                    float: right;
                                        
                                    width: 70%;
                                    border-radius: 25px;
                                    background-color: #78e08f;
                                    padding: 10px;
                                    position: relative;
                                    word-break: 1px;
                                    word-wrap: break-word;
                                    
                                    
                                ";
                                
                                echo "<p style='$is'>
									$msgg 
                                </p>";
                                echo "<br>";
                                
                            }
                            ?>
							
							<!-- 
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									
								</div>
								<div class="msg_cotainer">
									I am looking for your next templates
									<span class="msg_time">9:07 AM, Today</span>
								</div>
							</div> -->
                            <span class='msg_time_send'>9:05 AM, Today</span>
								</div>
								<div class='img_cont_msg'>
							
								</div>
							</div>
							
						</div>
                        
						<div class="card-footer"> 
							<div class="input-group">
								<div class="input-group-append">
									<span class="input-group-text attach_btn"><i class="fas fa-paperclip"></i></span>
								</div>
                                <form action="chat.php" method="post">
                                    <div class="row">
                                        <div class="col-md-10">
								<textarea name="text" style="border-radius: 45px;" class="form-control type_msg" placeholder="Type your message..." cols="70" rows="5"></textarea>
                                </div>
								<div class="input-group-append">
									<button type="submit" class="btn btn-info" name="send">Send</button>
								</div>
                                
                                </div>
                                </form>
							</div>
						</div>
                        
					</div>
				</div>
			</div>
		</div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="http://www.creative-tim.com">
                                Creative Tim
                            </a>
                        </li>
                        <li>
                            <a href="http://blog.creative-tim.com">
                               Blog
                            </a>
                        </li>
                        <li>
                            <a href="http://www.creative-tim.com/license">
                                Licenses
                            </a>
                        </li>
                    </ul>
                </nav>
				<div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <i class="fa fa-heart heart"></i> by <a href="http://www.creative-tim.com">Creative Tim</a>
                </div>
            </div>
        </footer>


    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

    

</html>

<?php
$sel=mysqli_query($conn, "SELECT * FROM `admin`");
while($log=mysqli_fetch_array($sel)){
   $id=$log['id'];
}
 if(isset($_POST['send'])){
    $msg=$_POST['text'];
    $sql=mysqli_query($conn, "INSERT INTO msg VALUES ('','$uidd','$id','$msg')");
 }

?>